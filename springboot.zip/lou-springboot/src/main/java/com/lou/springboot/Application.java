package com.lou.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Hello shiyanlou!
 *
 */
@SpringBootApplication
@MapperScan("com.lou.springboot.dao") //开启mybatis扫描
@EnableScheduling // 使定时任务生效
public class Application {

    public static void main(String[] args) {
        System.out.println("启动 Spring Boot...");
        SpringApplication.run(Application.class, args);
    }
}
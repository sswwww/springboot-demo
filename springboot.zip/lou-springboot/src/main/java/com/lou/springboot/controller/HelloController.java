package com.lou.springboot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class HelloController {

    private static final Logger logger = LoggerFactory.getLogger(HelloController.class);

    @GetMapping("/hello")
    @ResponseBody
    public String hello(String name){
        return "hello world" + name;
    }

    @GetMapping("/log")
    @ResponseBody
    public String log(){
        logger.info("info");
        logger.error("error");
        logger.debug("debug");
        logger.warn("warn");
        return "打印日志";
    }

}
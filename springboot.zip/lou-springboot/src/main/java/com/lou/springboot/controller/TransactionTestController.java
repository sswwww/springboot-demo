package com.lou.springboot.controller;

import com.lou.springboot.service.TransactionTestService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import javax.annotation.Resource;

@Controller
public class TransactionTestController {

    @Resource
    private TransactionTestService transactionTestService;

    @GetMapping("/transactionTest")
    @ResponseBody
    public String transactionTest() {
        transactionTestService.test2();
        return "success";
    }

}
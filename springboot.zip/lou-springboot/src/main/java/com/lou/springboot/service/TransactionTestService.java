package com.lou.springboot.service;

import com.lou.springboot.dao.UserDao;
import com.lou.springboot.entity.User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.Resource;

@Service
public class TransactionTestService {

    @Resource
    UserDao userDao;

    @Transactional
    public Boolean test2() {
        User user = new User();
        user.setPassword("1113123134");
        user.setName("test2");
        userDao.insertUser(user);
        return true;
    }

}